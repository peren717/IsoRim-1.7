IsoRim weapon models, batch 1 (for review), shaped after the game's sprites (rimworldwiki.com)

monosword.obj, plasmasword.obj, zeushammer.obj      Royalty (persona versions can share these)
toxbomb_launcher.obj                                Biotech
incinerator.obj                                     Anomaly

Built in Blender 5.2 (bpy) with make_weapons.py. Same conventions as IsoRim's own Models/*.obj:
one unit = one map cell, +Y up, grip at the origin, muzzle / tip along +X, materials from
Models/isorim.mtl (mtllib isorim.mtl, no .mtl of their own). Drop the .obj files into Models/.

batch1_sheet.png: the game sprite next to a side and a 3/4 render of each model.
previews/: the renders. Colours there are approximate; in game the isorim.mtl swatches are used.
