IsoRim weapon models, batch 3 (approved), shaped after the game's sprites (rimworldwiki.com)

jade_knife.obj            base game (jade knife)
beam_graser.obj           Biotech
beam_repeater.obj         Odyssey
persona_monosword.obj     Royalty, persona (bladelink) monosword
persona_plasmasword.obj   Royalty, persona plasmasword
persona_zeushammer.obj    Royalty, persona zeushammer

Built in Blender 5.2 (bpy) with make_weapons.py. Same conventions as IsoRim's own Models/*.obj:
one unit = one map cell, +Y up, grip at the origin, muzzle / tip along +X, materials from
Models/isorim.mtl (mtllib isorim.mtl, no .mtl of their own). Faces are triangles. Drop the
.obj files into Models/.

Vertex colours: these files write a colour after each vertex ("v x y z r g b"), which IsoRim's
.obj reader uses instead of the material's colour (as pit_burrow.obj and pit_gate.obj do), for
colours isorim.mtl has no material for (pinks, maroons, the jade's darker green). The
materials' texture swatches still apply. Vertices without a special colour carry their
material's own isorim.mtl colour, so they look as before.

The Odyssey unique weapons need no new models: bind each to its base gun's model.

batch3_sheet.png: the game sprite next to a side and a 3/4 render of each model.
previews/: the renders (colours approximate).
