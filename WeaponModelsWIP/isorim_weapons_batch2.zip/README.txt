IsoRim weapon models, batch 2 (approved), shaped after the game's sprites (rimworldwiki.com)

eltex_staff.obj     Royalty
flamebow.obj        Biotech
grenade_tox.obj     Biotech (tox grenades; one grenade, as IsoRim's frag grenade)
nerve_spiker.obj    Anomaly
hellcat_rifle.obj   Anomaly

Built in Blender 5.2 (bpy) with make_weapons.py. Same conventions as IsoRim's own Models/*.obj:
one unit = one map cell, +Y up, grip at the origin, muzzle / tip along +X, materials from
Models/isorim.mtl (mtllib isorim.mtl, no .mtl of their own). Faces are triangles (IsoRim fans
polygons from their first corner). Drop the .obj files into Models/.

Binding notes:
- flamebow: upright like IsoRim's bows (string at x = -0.03), so bind it like Bow_Great.
- nerve_spiker: a crossbow whose sprite is its top view. Bind it WITHOUT layFlat so it lies
  limbs-down on the ground and shows the sprite's cross from above (layFlat tips a model onto
  its side). Its grip reaches 0.15 below the origin; an offset may be needed so it doesn't sink.

batch2_sheet.png: the game sprite next to a side and a 3/4 render of each model;
nerve_spiker_views.png adds the view from above. previews/: the renders (colours approximate).
