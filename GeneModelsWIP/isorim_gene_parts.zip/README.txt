IsoRim gene part models (Biotech), approved, after the game's gene icons and pawn sprites (rimworldwiki.com)

gene_pig_ears.obj, gene_pig_nose.obj        Pigskin: Pig ears, Pig nose
gene_mini_horns.obj                         Impid: Mini-horns
gene_furry_tail.obj                         Yttakin: Furry tail
gene_furskin_<build>_upper.obj / _lower.obj Yttakin: Furskin, the coat, for male, female, thin, fat, hulk
gene_furskin_head.obj                       Yttakin: Furskin on the head (top, back, sides, cheeks; face open)

Built in Blender 5.2 (bpy) with make_genes.py. Placed in IsoRim's figure space, like
Models/person_head.obj and person_<build>_upper/_lower.obj (one unit = one map cell, +Y up,
-Z = the face's side, a figure of size 1), so each sits where it belongs on a figure as built.
The coat pieces follow the body part they cover (upper / lower), like worn clothes. Faces are
triangles. Drop the .obj files into Models/.

Colours (materials from Models/isorim.mtl):
- stuff_plain (and stuff_plain_light for the pig ears' inner face and the snout's front) is
  tinted like IsoRim's head and hair:
    pig ears, pig nose                      the skin colour
    furry tail, coat, head fur              the hair colour (RimWorld draws furskin in it)
- When a person has Furskin, tint the head itself (person_head) with the hair colour too, so the
  face matches the fur (no model: a colour rule for the code; see previews/yttakin_full.png).
- an_horn for the horns, an_dark for the nostrils.

For the code that will draw these (IsoRim does not draw gene parts yet):
- Hide or tuck the head fur under headgear as IsoRim does hair (HairTuck).
- Yttakin have the No hair gene: the head fur replaces hair; their beard (Unisex beards) shows.
- The tail sits at the lower back of a size-1 figure; on wide builds (fat) its root is inside the
  body, which is fine, or move it back by the build's half depth.

previews/: Blender renders on IsoRim's own figure (preview colours: a pale skin, brown or the
Yttakin sprite's orange-brown hair), next to the game's references.
